/*Nomes:
Abel Andrade Prazeres dos Santos
Bruna de Souza Brasil
Gabriel Gregório dos Santos Vitor
Gabriela Silva Malveira
*/
#include <stdlib.h>
#include "avl.h"

// Função para criar um novo nó
Avl* criarAvl(int info, Avl* pai) {
    Avl* novo = (Avl*)malloc(sizeof(Avl));
    if (novo) {
        novo->info = info;
        novo->esq = novo->dir = NULL;
        novo->pai = pai;
        novo->fb = 0;
    }
    return novo;
}

// rotação a esquerda
Avl* rotL(Avl* avl) {
    Avl* b = avl->dir;
    Avl* pai = avl->pai;

    avl->dir = b->esq;
    if (avl->dir != NULL) {
        avl->dir->pai = avl;
    }

    b->esq = avl;
    avl->pai = b;
    b->pai = pai;

    // Atualizar fb
    int a_fb = avl->fb;
    int b_fb = b->fb;
    avl->fb = a_fb - 1 - (b_fb > 0 ? b_fb : 0);
    b->fb = b_fb - 1 + (a_fb < 0 ? a_fb : 0);

    return b;
}

// rotação a direita
Avl* rotR(Avl* a) {
    Avl* b = a->esq;
    Avl* pai = a->pai;

    a->esq = b->dir;
    if (a->esq != NULL) {
        a->esq->pai = a;
    }

    b->dir = a;
    a->pai = b;
    b->pai = pai;

    // Atualizar fb
    int a_fb = a->fb;
    int b_fb = b->fb;
    a->fb = a_fb + 1 - (b_fb < 0 ? b_fb : 0);
    b->fb = b_fb + 1 + (a_fb > 0 ? a_fb : 0);

    return b;
}

// balancear a arvore
Avl* balancear(Avl* node) {
    if (node->fb == 2) { // Subarvore direita mais pesada
        if (node->dir->fb >= 0) { // Caso RR
            return rotL(node);
        } else { // Caso RL
            node->dir = rotR(node->dir);
            return rotL(node);
        }
    } else if (node->fb == -2) { // Subarvore esquerda mais pesada
        if (node->esq->fb <= 0) { // Caso LL
            return rotR(node);
        } else { // Caso LR
            node->esq = rotL(node->esq);
            return rotR(node);
        }
    }
    return node; 
}

// inserção principal
Avl* inserirAvl(Avl* avl, int info) {
    // Criar novo no
    Avl* novo = criarAvl(info, NULL);
    if (!novo) return avl;

    // Caso a arvore esteja vazia
    if (avl == NULL) {
        return novo;
    }

    // Encontrar a posição correta para inserir
    Avl* atual = avl;
    Avl* pai = NULL;
    while (atual != NULL) {
        pai = atual;
        if (info < atual->info) {
            atual = atual->esq;
        } 
        else{
            atual = atual->dir;
        }
    }

    // Conectar o novo no ao pai
    novo->pai = pai;
    if (info < pai->info) {
        pai->esq = novo;
    } else {
        pai->dir = novo;
    }

    // Atualizar fb e balancear se necessário
    atual = pai;
    while (atual != NULL) {
        // Atualizar o fb
        if (novo == atual->esq) {
            atual->fb--;
        } else {
            atual->fb++;
        }

        // Verificar necessidade de balanceamento
        if (atual->fb == 0) {
            break; // Altura nao mudou, encerrar
        } else if (atual->fb == 2 || atual->fb == -2) {
            Avl* paiAtual = atual->pai;
            Avl* subAvl = balancear(atual);

            // Atualizar o pai
            if (paiAtual == NULL) {
                avl = subAvl; // Nova raiz
            } else {
                if (paiAtual->esq == atual) {
                    paiAtual->esq = subAvl;
                } else {
                    paiAtual->dir = subAvl;
                }
            }
            break; // Altura ajustada, encerrar
        }

        // Subir para o proximo pai
        novo = atual;
        atual = atual->pai;
    }

    return avl;
}

// Free na arvore inteira
void liberarArvoreAvl(Avl* avl) {
    if (avl != NULL) {
        liberarArvoreAvl(avl->esq);
        liberarArvoreAvl(avl->dir);
        free(avl);
    }
}

// Busca na arvore
void buscaAvl(Avl* avl, int chave){
    while (avl != NULL) {
        if (avl->info == chave) {
            return;
        } else if (chave < avl->info) {
            avl = avl->esq;
        } else {
            avl = avl->dir;
        }
    }
    return;
}

// funcao de calcular a altura
int alturaAvl(Avl* avl) {
    if (avl == NULL) {
        return -1;  // altura inicial = -1
    }
    
    int altura_esq = alturaAvl(avl->esq);
    int altura_dir = alturaAvl(avl->dir);
    
    return 1 + (altura_esq > altura_dir ? altura_esq : altura_dir); // verificar qual lado tem maior altura e retornar o maior
}