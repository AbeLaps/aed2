/*Nomes:
Abel Andrade Prazeres dos Santos
Bruna de Souza Brasil
Gabriel Gregório dos Santos Vitor
Gabriela Silva Malveira
*/
#include <stdlib.h>
#include "avl.h"

// Função para criar um novo nó
Avl* criarAvl(int info, Avl* pai) {
    Avl* novo = (Avl*)malloc(sizeof(Avl));
    if (novo) {
        novo->info = info;
        novo->esq = novo->dir = NULL;
        novo->pai = pai;
        novo->fb = 0;
    }
    return novo;
}

// Função para realizar a rotação à esquerda
Avl* rotL(Avl* avl) {
    Avl* b = avl->dir;
    Avl* pai = avl->pai;

    avl->dir = b->esq;
    if (avl->dir != NULL) {
        avl->dir->pai = avl;
    }

    b->esq = avl;
    avl->pai = b;
    b->pai = pai;

    // Atualizar fatores de balanceamento
    int a_fb = avl->fb;
    int b_fb = b->fb;
    avl->fb = a_fb - 1 - (b_fb > 0 ? b_fb : 0);
    b->fb = b_fb - 1 + (a_fb < 0 ? a_fb : 0);

    return b;
}

// Função para realizar a rotação à direita
Avl* rotR(Avl* a) {
    Avl* b = a->esq;
    Avl* pai = a->pai;

    a->esq = b->dir;
    if (a->esq != NULL) {
        a->esq->pai = a;
    }

    b->dir = a;
    a->pai = b;
    b->pai = pai;

    // Atualizar fatores de balanceamento
    int a_bf = a->fb;
    int b_bf = b->fb;
    a->fb = a_bf + 1 - (b_bf < 0 ? b_bf : 0);
    b->fb = b_bf + 1 + (a_bf > 0 ? a_bf : 0);

    return b;
}

// Função para balancear a arvore
Avl* balancear(Avl* node) {
    if (node->fb == 2) { // Subarvore direita mais pesada
        if (node->dir->fb >= 0) { // Caso RR
            return rotL(node);
        } else { // Caso RL
            node->dir = rotR(node->dir);
            return rotL(node);
        }
    } else if (node->fb == -2) { // Subarvore esquerda mais pesada
        if (node->esq->fb <= 0) { // Caso LL
            return rotR(node);
        } else { // Caso LR
            node->esq = rotL(node->esq);
            return rotR(node);
        }
    }
    return node; 
}

// Função principal de inserção
Avl* inserirAvl(Avl* avl, int info) {
    // Criar novo nó
    Avl* novo = criarAvl(info, NULL);
    if (!novo) return avl;

    // Caso a árvore esteja vazia
    if (avl == NULL) {
        return novo;
    }

    // Encontrar a posição correta para inserir
    Avl* atual = avl;
    Avl* pai = NULL;
    while (atual != NULL) {
        pai = atual;
        if (info < atual->info) {
            atual = atual->esq;
        } 
        else{
            atual = atual->dir;
        }
    }

    // Conectar o novo nó ao pai
    novo->pai = pai;
    if (info < pai->info) {
        pai->esq = novo;
    } else {
        pai->dir = novo;
    }

    // Atualizar fatores de balanceamento e balancear se necessário
    atual = pai;
    while (atual != NULL) {
        // Atualizar o fator de balanceamento
        if (novo == atual->esq) {
            atual->fb--;
        } else {
            atual->fb++;
        }

        // Verificar necessidade de balanceamento
        if (atual->fb == 0) {
            break; // Altura não mudou, encerrar
        } else if (atual->fb == 2 || atual->fb == -2) {
            Avl* paiAtual = atual->pai;
            Avl* subAvl = balancear(atual);

            // Atualizar a ligação do pai
            if (paiAtual == NULL) {
                avl = subAvl; // Nova raiz da árvore
            } else {
                if (paiAtual->esq == atual) {
                    paiAtual->esq = subAvl;
                } else {
                    paiAtual->dir = subAvl;
                }
            }
            break; // Altura ajustada, encerrar
        }

        // Subir para o próximo ancestral
        novo = atual;
        atual = atual->pai;
    }

    return avl;
}

// free na arvore inteira
void liberarArvoreAvl(Avl* avl) {
    if (avl != NULL) {
        liberarArvoreAvl(avl->esq);
        liberarArvoreAvl(avl->dir);
        free(avl);
    }
}

// busca na arvore
void buscaAvl(Avl* avl, int chave){
    while (avl != NULL) {
        if (avl->info == chave) {
            return;
        } else if (chave < avl->info) {
            avl = avl->esq;
        } else {
            avl = avl->dir;
        }
    }
    return;
}

int alturaAvl(Avl* avl) {
    if (avl == NULL) {
        return -1;  // Empty tree has height -1 (common convention)
    }
    
    int altura_esq = alturaAvl(avl->esq);
    int altura_dir = alturaAvl(avl->dir);
    
    return 1 + (altura_esq > altura_dir ? altura_esq : altura_dir);
}