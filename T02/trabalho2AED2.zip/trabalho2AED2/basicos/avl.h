/*Nomes:
Abel Andrade Prazeres dos Santos
Bruna de Souza Brasil
Gabriel Gregório dos Santos Vitor
Gabriela Silva Malveira
*/
#ifndef AVL_H
#define AVL_H

typedef struct Avl Avl;

struct Avl {
    int info;
    Avl* esq;
    Avl* dir;
    Avl* pai;
    int fb;
};

// Cria um novo nó (usado internamente)
Avl* criarAvl(int info, Avl* pai);

int alturaAvl(Avl* root);

// Função principal de inserção
Avl* inserirAvl(Avl* root, int info);

// Rotações (usadas internamente)
Avl* rotR(Avl* a);
Avl* rotL(Avl* a);

// Balanceamento (usado internamente)
Avl* balancear(Avl* node);

void liberarArvoreAvl(Avl* avl);

void buscaAvl(Avl* avl, int key);

#endif