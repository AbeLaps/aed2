/*Nomes:
Abel Andrade Prazeres dos Santos
Bruna de Souza Brasil
Gabriel Gregório dos Santos Vitor
Gabriela Silva Malveira
*/
#ifndef ABP_C
#define ABP_C

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "ABP.h"
#include "vetor.h"

// funcao para criar novo no
Arv* criaArv(int val){
    Arv *arv;
    arv = (Arv*) malloc(sizeof(Arv));
    arv->esq = NULL;
    arv->dir = NULL;
    arv->info = val;
    return arv;
}

// funcao de visita
void visita(Arv* arv){
    //if(arv->info != NULL){
    printf("%d ",arv->info);
    //}
    return;
}

// funcoes de encaminhamentos
void preFix(Arv* arv){
    if(arv != NULL){
    visita(arv);
    preFix(arv->esq);
    preFix(arv->dir);
    }

    return;
}

void posFix(Arv* arv){
    if(arv != NULL){
    posFix(arv->esq);
    posFix(arv->dir);
    visita(arv);
    }

    return;
}

void inFix(Arv* arv){
    if(arv != NULL){
    inFix(arv->esq);
    printf("%d  ",arv->info);
    inFix(arv->dir);
    }
    return;
}

// funcao para verificar altura da arvore
int alturaAbp(Arv* arv) {
    if (arv == NULL) {
        return -1;
    }
    
    int altura_esq = alturaAbp(arv->esq);
    int altura_dir = alturaAbp(arv->dir);
    
    return 1 + (altura_esq > altura_dir ? altura_esq : altura_dir);
}

// funcao principal de insercao
void insereValArv(Arv* arv, int val){
    Arv* aux = arv;
    while(aux != NULL){
    if(aux->info < val){
        if(aux->dir == NULL){ // colocar como filho a direita
            aux->dir = criaArv(val);
            return;
        }
        aux = aux->dir;
    }
    else{
        if(aux->esq == NULL){ // colocar como filho a esquerda
            aux->esq = criaArv(val);
            return;
        }
        aux=aux->esq;
    }
    }
    printf("erro: arvore de entrada nao existe");
    return;
}

// funcao de popular um arvore aleatoriamente
void popularArvRand(Arv* arv, int tam){
    if(arv == NULL){return;}
    for(int i = 0; i < tam;i++){
        int k = rand();
        insereValArv(arv,k);
    }
}

// funcoes para popular uma arvore com um tipoVetor
void pegaMeio (Arv* arv, tipoVetor *v, int ini, int fim){
    if (ini > fim){ return; } 
    int i = ini;
    int j = fim;
    int meio = (i+j)/2;
    insereValArv(arv, v->vet[meio]);
    pegaMeio(arv, v, ini, meio - 1);
    pegaMeio(arv, v, meio + 1, fim);
    return;
}
void popularArvVet(Arv* arv, tipoVetor *vet){
    if(vet == NULL){return;}
    insereValArv(arv,vet->tam/2);
    pegaMeio(arv, vet, 0, vet->tam/2 - 1);
    pegaMeio(arv, vet, vet->tam/2 + 1,vet->tam);
}

// funcoes para popular uma arvore com vetores nativos
void pegaMeioN(Arv* arv, int vet[], int ini, int fim){
    if (ini > fim){ return; } 
    int i = ini;
    int j = fim;
    int meio = (i+j)/2;
    insereValArv(arv, vet[meio]);
    pegaMeioN(arv, vet, ini, meio - 1);
    pegaMeioN(arv, vet, meio + 1, fim);
    return;
}

void popularArvVetN(Arv* arv, int vet[], int tam){
    if(vet == NULL){return;}
    insereValArv(arv,vet[tam/2]);
    pegaMeioN(arv, vet, 0, vet[tam/2] - 1);
    pegaMeioN(arv, vet, vet[tam/2] + 1, vet[tam]);
}

// funcao de busca
Arv* buscaABP(Arv* arv, int chave){
    if (arv == NULL || arv->info == chave) {
        return arv;
    }
    else if (arv->info < chave) {
        return buscaABP(arv->dir, chave);
    }
    else {
        return buscaABP(arv->esq, chave);
    }
}

// funcao de matar arvore completa
void liberarArvoreABP(Arv* raiz) {
    if (raiz != NULL) {
        liberarArvoreABP(raiz->esq);
        liberarArvoreABP(raiz->dir);
        free(raiz);
    }
}
#endif
