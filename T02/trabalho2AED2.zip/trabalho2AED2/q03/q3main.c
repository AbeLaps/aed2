/*Nomes:
Abel Andrade Prazeres dos Santos
Bruna de Souza Brasil
Gabriel Gregório dos Santos Vitor
Gabriela Silva Malveira
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 
#include "vetor.h"
#include "ABP.h"

#define TAM_VET (int) 1e9

int main() {
    FILE *arquivo1 = fopen("tempos_buscaVet.txt", "w");
    if (arquivo1 == NULL) {
        printf("Erro ao abrir arquivo!\n");
        return 1;
    }
    FILE *arquivo2 = fopen("tempos_buscaABP.txt", "w");
    if (arquivo2 == NULL) {
       printf("Erro ao abrir arquivo!\n");
       return 1;
    }
    int z;
    printf("pausa antes do vetor");
    scanf("%d",&z);
    tipoVetor v;
    criaVetor(&v,TAM_VET);

    preencheVetorOrdenado(&v);
    printf("pausa dps do vetor");
    scanf("%d",&z);
    int n,k;
    float tempo_tot = 0;

    for(int i = 0;i < 30 ;i++){
        if(i > 15){ //numero aleatorio
            n = rand();
            k=n;
        }
        else{
            n = rand() %TAM_VET; //numero aleatorio dentro do vetor
            k=v.vet[n];
        }
        clock_t tempoini = clock();
        buscaBin(v,k);
        clock_t tempof = clock();
        tempo_tot = ((float)(tempof - tempoini) / CLOCKS_PER_SEC);
        fprintf(arquivo1, "%d;%.40f\n", i, tempo_tot);
    }
    fclose(arquivo1);
    printf("Tempos salvos em tempos_busca_binariaVet.txt\n");
    Arv* arv = criaArv(v.vet[(v.tam)/2]);
    popularArvVet(arv,&v);
    printf("pausa com arv e vetor na memoria");
    scanf("%d",&z);
    for(int i = 0;i < 30 ;i++){
        if(i > 15){ //numero aleatorio
            n = rand();
            k=n;
        }
        else{
            n = rand() %  TAM_VET; //numero aleatorio dentro do arvore
            k=v.vet[n];
        }
        //printf("fazendo...\n");
        clock_t tempoini = clock();
        buscaABP(arv,k);
        clock_t tempof = clock();
        tempo_tot = ((float)(tempof - tempoini) / CLOCKS_PER_SEC);
        fprintf(arquivo2, "%d;%.40f\n", i, tempo_tot);
    }
    fclose(arquivo2);
    printf("Tempos salvos em tempos_busca_binariaABP.txt\n");

    return 1;
}
