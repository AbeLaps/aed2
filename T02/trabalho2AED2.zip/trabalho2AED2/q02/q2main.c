/*Nomes:
Abel Andrade Prazeres dos Santos
Bruna de Souza Brasil
Gabriel Gregório dos Santos Vitor
Gabriela Silva Malveira
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "pacote.h"




int main() {
    ArvPacote* arvore = NULL;
    int totalPacotes = 100;
    float probabilidadeRetransmissao = 0.2;

    simularChegadaDePacotes(&arvore, totalPacotes, probabilidadeRetransmissao);

    printf("Exibindo pacotes na ordem pré-fixada:\n");
    ordenaArquivo(arvore, stdout);

    FILE* arquivo = fopen("pacotes_recebidos.txt", "w");
    if (arquivo != NULL) {
        salvarEmArquivo(arvore, arquivo);
        fclose(arquivo);
        printf("Arquivo criado.\n");
    } else {
        printf("Erro ao criar o arquivo.\n");
    }

    return 0;
}
