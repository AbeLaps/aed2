/*Nomes:
Abel Andrade Prazeres dos Santos
Bruna de Souza Brasil
Gabriel Gregório dos Santos Vitor
Gabriela Silva Malveira
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pacote.h"

// funcao de criar pacote
ArvPacote* criaPacote (int num, char * nome){
    ArvPacote* no = (ArvPacote*) malloc(sizeof(ArvPacote));
    Pacote* p = (Pacote*) malloc(sizeof(Pacote));
    p->id = num;
    strcpy(p->dado, nome); 
    no->pacote = p;
    no->esq = no->dir = NULL;
    return no;
}

// funcao de inserir pacote na arvore
ArvPacote* inserePacote(ArvPacote *no, int num, char * nome) {
    if (no == NULL) {
        return criaPacote(num, nome);
    }
    if (num < no->pacote->id) {
        no->esq = inserePacote(no->esq, num, nome);
    } else if (num > no->pacote->id) {
        no->dir = inserePacote(no->dir, num, nome);
    } else {
        strcpy(no->pacote->dado, nome);
    }
    return no;
}

// funcao de ordenar arquivos
void ordenaArquivo(ArvPacote* no, FILE* f) {
    if (no == NULL) {
        return;
    }
    ordenaArquivo(no->esq, f);
    fprintf(f, "ID: %d, Dado: %s\n", no->pacote->id, no->pacote->dado);
    ordenaArquivo(no->dir, f);
}

// funcao para simular envio de pacotes com probabilidade de restransmissao
void simularChegadaDePacotes(ArvPacote** arvore, int totalPacotes, float probabilidadeRetransmissao) {
    srand(time(NULL));

    for (int i = 0; i < totalPacotes; i++) {
        int pacote = rand() % 100;
        char nome[100];
        snprintf(nome, sizeof(nome), "Pacote-%d", pacote);

        if (rand() % 100 < probabilidadeRetransmissao * 100) {
            printf("Retransmissão do pacote: %d\n", pacote);
        } else {
            printf("Chegada do pacote: %d\n", pacote);
            *arvore = inserePacote(*arvore, pacote, nome); 
        }
    }
}

// funcao de salvar uma arvore de pacotes em um arquivo
void salvarEmArquivo(ArvPacote* arvore, FILE* arquivo) {
    if (arvore != NULL) {
        salvarEmArquivo(arvore->esq, arquivo);
        fprintf(arquivo, "ID: %d, Dados: %s\n", arvore->pacote->id, arvore->pacote->dado);
        salvarEmArquivo(arvore->dir, arquivo);
    }
}